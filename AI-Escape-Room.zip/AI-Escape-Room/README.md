# AI Escape Room · The Locked Library

Explore a locked library, find the brass key, and piece together three number clues to open the exit. This project compares a Gemini-led game with a version that validates puzzle progress in Python. Both use the same room and browser interface.

[Watch the 33-second Version 2 demo](docs/v2-demo.mp4).

## Run locally

1. Install Python 3.10 or later. The app uses the Python standard library and a browser. There are no packages to install.
2. For Version 1 or to enable Gemini narration in Version 2, copy `.env.example` to `.env` and set `GEMINI_API_KEY` to a key from [Google AI Studio](https://aistudio.google.com/apikey). Use a project eligible for the [Gemini free tier](https://ai.google.dev/gemini-api/docs/pricing). Set `GEMINI_MODEL` if your account uses a different model. Environment variables take precedence over `.env`. Version 2 runs offline with an empty key.
3. Run `python app.py` from the repository root and open [http://localhost:8000](http://localhost:8000). Set a different port with `python app.py --port 8001` if needed.
4. Use the version buttons to switch between independent games. Enter one action at a time, such as “I want to examine the bookshelf”. Select **Restart room** to clear the current version. Reloading starts a fresh session.

`.env` is ignored by Git. The server reads the key and keeps it out of browser responses. The app is intended for local use and keeps sessions in memory.

## Version 1 · Gemini-led

[Version 1 source](versions/v1.py). Gemini receives the complete room design and conversation so far. It plays the Game Master, interprets the player's language, narrates each turn, and returns a JSON escape flag. Python checks the JSON shape and uses that flag to update completion.

```mermaid
flowchart LR
    A["Browser transcript"] -->|Player action| B["Python web app"]
    B -->|Rules and transcript| C["Gemini Game Master"]
    C -->|Narration and escape flag| B
    B -->|New turn| A
    B <-->|Turns and completion| D["Session history"]
```

## Version 2 · Rule-checked

[Version 2 source](versions/v2.py). Python keeps inventory, discovered clues, drawer status and escape status. The parser recognizes supported one-action phrases. The rule engine applies prerequisites before changing the room state. Gemini chooses a sentence from approved options for successful actions. Python produces every factual outcome and verifies the chosen sentence. The model receives only the atmospheric options for that turn.

```mermaid
flowchart TD
    A["Browser transcript"] -->|Player action| B["Python action parser"]
    B --> C["Python rule engine"]
    C <-->|Validate and update| D["Structured room state"]
    C -->|Factual outcome| F["Reply builder"]
    C -->|Approved options| E["Optional Gemini narration"]
    E -->|Checked choice or fallback| F
    F -->|Reply and progress| A
```

Version 1 accepts a well-formed escape flag even when the app has no independent record of the prerequisites. The tests reproduce that design limitation with a synthetic model response. Version 2 puts those prerequisites in code and keeps them in effect during provider errors. The trade-off is that Version 2 understands a smaller range of phrases and Gemini supplies atmosphere within a limited vocabulary.

## Verification and demo

Run `python -m unittest discover -s tests -v`. See [test cases and evidence](docs/testing.md), the [recorded Version 2 demo](docs/v2-demo.mp4), and the [project report](docs/project-report.pdf). The report and tests include puzzle spoilers. The V1 model tests use stubs. Live Gemini calls require a working key and were not verified here.

## Git history

Use `git log --oneline` from the repository root to see the room design, state engine, browser interface, tests and documentation as separate commits. The version selector and the `versions/v1.py` and `versions/v2.py` modules identify the two implementations.

### Publish the packaged repository

After extracting the download, either open the included source tree for review or clone the Git bundle to recover the full commit history:

```sh
git clone -b main AI-Escape-Room.bundle AI-Escape-Room-repo
cd AI-Escape-Room-repo
git log --oneline
```

For an empty GitHub repository you own, point the clone at its HTTPS URL, substituting your GitHub username, then push:

```sh
git remote set-url origin https://github.com/YOUR-USERNAME/AI-Escape-Room.git
git push -u origin main
```
