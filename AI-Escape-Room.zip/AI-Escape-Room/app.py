"""Local web interface for both escape-room versions."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import argparse
import json
from pathlib import Path
from threading import Lock

from versions import gemini, v1, v2
from versions.room import INTRO

HTML = Path(__file__).with_name("index.html")
SESSIONS = {}
SESSIONS_LOCK = Lock()
MAX_SESSIONS = 256


class Session:
    def __init__(self):
        self.games = {"1": v1.Game(), "2": v2.Game()}
        self.lock = Lock()


class Handler(BaseHTTPRequestHandler):
    def send_data(self, status, body, mime):
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/":
            self.send_data(200, HTML.read_bytes(), "text/html; charset=utf-8")
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path != "/play":
            self.send_error(404)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 1 <= size <= 4096 or self.headers.get_content_type() != "application/json":
                raise ValueError
            payload = json.loads(self.rfile.read(size))
            version = payload["version"]
            action = payload["action"]
            session_id = payload["session"]
            if not isinstance(session_id, str) or len(session_id) != 32 or any(char not in "0123456789abcdef" for char in session_id):
                raise ValueError
            if version not in ("1", "2") or not isinstance(action, str) or not 1 <= len(action.strip()) <= 500:
                raise ValueError
        except (KeyError, TypeError, ValueError):
            self.send_error(400)
            return
        with SESSIONS_LOCK:
            session = SESSIONS.get(session_id)
            if session is None:
                session = Session()
                if len(SESSIONS) >= MAX_SESSIONS:
                    SESSIONS.pop(next(iter(SESSIONS)))
                SESSIONS[session_id] = session

        with session.lock:
            if action == "/restart":
                session.games[version] = v1.Game() if version == "1" else v2.Game()
                reply = INTRO
            else:
                reply = session.games[version].play(action)
            game = session.games[version]
            response = {"reply": reply, "escaped": game.escaped, "status": game.status}
            if version == "2":
                response["inventory"] = sorted(game.state.inventory)
                response["clues"] = len(game.state.puzzles)

        self.send_data(200, json.dumps(response).encode(), "application/json")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8000)
    options = parser.parse_args()
    gemini.load_settings()
    address = ("127.0.0.1", options.port)
    print(f"AI Escape Room · http://{address[0]}:{address[1]}", flush=True)
    with ThreadingHTTPServer(address, Handler) as server:
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
