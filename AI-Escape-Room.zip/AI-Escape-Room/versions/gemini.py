"""Small server-side Gemini REST adapter using Python's standard library."""

import json
import os
from pathlib import Path
import re
from urllib.error import URLError
from urllib.request import Request, urlopen


class ModelUnavailable(Exception):
    pass


def load_settings():
    path = Path(__file__).resolve().parents[1] / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            name, separator, value = line.partition("=")
            if separator and name.strip() in {"GEMINI_API_KEY", "GEMINI_MODEL"}:
                os.environ.setdefault(name.strip(), value.strip().strip("\"'"))


def configured():
    return bool(os.getenv("GEMINI_API_KEY"))


def generate(system, messages, *, structured=False):
    key = os.getenv("GEMINI_API_KEY")
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite")
    if not key or not re.fullmatch(r"[a-zA-Z0-9-]+", model):
        raise ModelUnavailable
    config = {"temperature": 0.2, "maxOutputTokens": 512}
    if structured:
        config.update(
            responseMimeType="application/json",
            responseSchema={
                "type": "OBJECT",
                "properties": {
                    "narration": {"type": "STRING"},
                    "escaped": {"type": "BOOLEAN"},
                },
                "required": ["narration", "escaped"],
            },
        )
    payload = {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": [
            {"role": role, "parts": [{"text": message}]} for role, message in messages
        ],
        "generationConfig": config,
    }
    request = Request(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "x-goog-api-key": key},
    )
    try:
        with urlopen(request, timeout=12) as response:
            result = json.load(response)
        parts = result["candidates"][0]["content"]["parts"]
        answer = "".join(part.get("text", "") for part in parts if not part.get("thought")).strip()
        if answer:
            return answer
    except (URLError, OSError, ValueError, KeyError, IndexError, TypeError):
        pass
    raise ModelUnavailable
