"""The room's fixed design, shared by both versions."""

INTRO = (
    "You wake in a locked library. A green lamp lights a desk. Nearby are "
    "a bookshelf, a painting, a locked drawer and the exit door."
)
CLUES = {
    "desk": "A brass key lies on the desk.",
    "bookshelf": "An index card says: read numbers in Shelf → Frame → Drawer order. Shelf: 47.",
    "painting": "An inscription inside the frame reads: Frame: 2.",
    "drawer": "A slip inside the drawer reads: Drawer: 9.",
    "door": "The exit has a four-digit keypad.",
}
CODE = "4729"
KEY = "brass key"
