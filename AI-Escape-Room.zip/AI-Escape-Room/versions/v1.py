"""Version 1 trusts Gemini to track the room and decide when the player escapes."""

import json

from .gemini import generate, ModelUnavailable
from .room import CLUES, CODE, INTRO

SYSTEM = f"""You are the Game Master of a library escape room.
Opening scene: {INTRO}
These are the only objects and their examine results: {CLUES}
Reveal a clue only when its object is examined. Reveal the drawer slip only
after unlocking the drawer. Track actions through the conversation. The player
must examine the desk before taking the brass key, then use it to unlock the
drawer. Require all three clues to have been discovered and the actual digits
{CODE} to be entered on the door before marking escaped. Keep the code private
and never invent objects. Respond in 1–3 sentences from the room's perspective.
Set escaped to true only if the player successfully leaves through the exit."""


class Game:
    def __init__(self):
        self.history = []
        self.escaped = False
        self.status = "Gemini Game Master"

    def play(self, action):
        if self.escaped:
            return "You already escaped. Restart to play again."
        messages = [*self.history, ("user", action)]
        try:
            raw = generate(SYSTEM, messages, structured=True)
            result = json.loads(raw)
            narration = result["narration"].strip()
            if not narration or type(result["escaped"]) is not bool:
                raise ValueError
        except (ModelUnavailable, ValueError, KeyError, TypeError, AttributeError):
            self.status = "Gemini unavailable"
            return "Gemini could not respond. Check your API key, model or quota, then retry."
        self.history = [*messages, ("model", raw)]
        self.escaped = result["escaped"]
        self.status = "Gemini Game Master"
        return narration
