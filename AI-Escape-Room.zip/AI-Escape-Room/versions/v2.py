"""Version 2 validates actions and gives Gemini a choice of approved narration."""

from dataclasses import dataclass, field
import re

from .gemini import configured, generate, ModelUnavailable
from .room import CLUES, CODE, KEY


FLAVOR = {
    "examine": ("The lamplight steadies.", "Dust drifts through the light."),
    "collect": ("Your footsteps echo softly.", "The library falls quiet."),
    "drawer": ("A small click breaks the silence.", "The old wood creaks."),
    "escape": ("Cool air reaches you.", "The silence gives way to a distant breeze."),
}
OBJECTS = "|".join(CLUES)
HELP = "Try examining a room object, taking the brass key, or entering four digits on the door."


@dataclass
class RoomState:
    objects: tuple = tuple(CLUES)
    examined: set = field(default_factory=set)
    inventory: set = field(default_factory=set)
    puzzles: set = field(default_factory=set)
    drawer_open: bool = False
    escaped: bool = False


def parse(action):
    """Recognize one complete action. Anything else leaves the room untouched."""
    text = " ".join(action.lower().split()).rstrip(".!?")
    text = re.sub(r"^(?:please |i (?:want to |would like to |try to )?|can i )", "", text)
    examined = re.fullmatch(
        rf"(?:examine|inspect|look at|check|investigate|search|look inside) "
        rf"(?:the )?({OBJECTS})", text
    )
    if examined:
        return "examine", examined[1]
    if re.fullmatch(r"(?:take|pick up|collect|grab) (?:the )?(?:brass )?key", text):
        return "collect", KEY
    if re.fullmatch(
        r"(?:use (?:the )?(?:brass )?key (?:on|to (?:open|unlock)) "
        r"|(?:open|unlock) )(?:the )?drawer(?: with (?:the )?(?:brass )?key)?", text
    ):
        return "drawer", ""
    digits = re.fullmatch(
        r"(?:(?:enter|try|type|punch in) (?:code )?)?"
        r"([0-9]{4})(?: (?:on|into) (?:the )?(door|keypad|exit|drawer))?", text
    )
    if digits:
        return ("drawer_code" if digits[2] == "drawer" else "escape"), digits[1]
    if text in {"inventory", "show inventory", "show my inventory", "what do i have"}:
        return "inventory", ""
    return "unknown", ""


class Game:
    def __init__(self):
        self.state = RoomState()
        self.status = "Local narration"

    @property
    def escaped(self):
        return self.state.escaped

    def play(self, action):
        if self.escaped:
            return "You already escaped. Restart to play again."
        verb, target = parse(action)
        outcome, scene = self.apply(verb, target)
        return outcome + self.narrate(scene)

    def apply(self, verb, target):
        state = self.state
        if verb == "inventory":
            return ("Inventory: " + (", ".join(sorted(state.inventory)) or "empty") + "."), None
        if verb == "examine" and target in state.objects:
            if target == "drawer" and not state.drawer_open:
                return "The drawer is locked. Its lock takes a key.", None
            state.examined.add(target)
            if target in {"bookshelf", "painting", "drawer"}:
                state.puzzles.add(target)
            return CLUES[target], "examine"
        if verb == "collect" and target == KEY:
            if KEY in state.inventory:
                return "The brass key is already in your inventory.", None
            if "desk" not in state.examined:
                return "Examine the desk first to find the key.", None
            state.inventory.add(KEY)
            return "You take the brass key.", "collect"
        if verb == "drawer_code":
            return "The drawer takes a key. The door has the keypad.", None
        if verb == "drawer":
            if state.drawer_open:
                return "The drawer is already open. You can examine it.", None
            if KEY not in state.inventory:
                return "You need to collect the brass key before opening the drawer.", None
            state.drawer_open = True
            return "You unlock the drawer with the brass key. You can now examine it.", "drawer"
        if verb == "escape":
            if state.puzzles != {"bookshelf", "painting", "drawer"}:
                return "The door stays locked. Discover all three number clues first.", None
            if target != CODE:
                return "The keypad flashes red. The door remains locked.", None
            state.escaped = True
            return "The keypad turns green. You open the door and escape!", "escape"
        return "That action is unavailable. " + HELP, None

    def narrate(self, scene):
        if scene is None or not configured():
            return ""
        phrases = FLAVOR[scene]
        prompt = "Choose exactly one of these two sentences and return it verbatim: " + repr(phrases)
        try:
            choice = generate("Select atmospheric narration for a library escape room.", [("user", prompt)])
        except ModelUnavailable:
            choice = ""
        if choice in phrases:
            self.status = "Gemini narration"
            return " " + choice
        self.status = "Local narration · Gemini fallback"
        return " " + phrases[0]
